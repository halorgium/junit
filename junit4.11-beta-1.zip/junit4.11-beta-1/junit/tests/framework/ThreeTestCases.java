package junit.tests.framework;

import junit.framework.TestCase;

/**
 * Test class used in SuiteTest
 */
public class ThreeTestCases extends TestCase {
    public void testCase() {
    }

    public void testCase2() {
    }

    public void testCase3thisTimeItsPersonal() {
    }
}